<?php
	# NINGHE ZHANG
	# CSE154
	# HW8
	# SECTION AJ
	#
	# This is the initial page that welcomes the user and let users make search.

	include("common.php");
	banner();
?>
				<h1>The One Degree of Kevin Bacon</h1>
				<p>Type in an actor's name to see if he/she was ever in a movie with Kevin Bacon!</p>
				<p><img src="https://webster.cs.washington.edu/images/kevinbacon/kevin_bacon.jpg" alt="Kevin Bacon" /></p>

<?php
	form_and_footer();
?>